# Aura

Professional AI companion with WhatsApp-style voice notes, ChatGPT-style talk mode, a local SQLite database, and a protected Kids Mode.

## Run

```bash
pip install -r requirements.txt
python app.py
```

Open `http://localhost:5000`.

## What you get

- **Chat** — facts, weather, maths, currency, definitions, conversation history
- **Voice notes** — record, waveform, play back (WhatsApp-style)
- **Live mic** — speech-to-text into the composer
- **Talk mode** — hands-free listen → reply → speak
- **Kids Mode** — Spark the mascot, stories, quizzes, riddles, gentler language, parent PIN
- **Database** — chats, voice files, and settings stored in `data/aura.db`

Voice features work best in Chrome or Edge (microphone + Web Speech API).
